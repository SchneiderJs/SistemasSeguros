# C:\DSS-TESTE\musica.mp3
# C:\DSS-TESTE\musica.mp3 & cd C:\ & dir 

import webbrowser
music_path = input("Informe o diretório da música: ")
webbrowser.open(music_path)